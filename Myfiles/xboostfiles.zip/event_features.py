"""
Event Feature Extractor for Rugby Analytics
Extracts ~200 statistical features per frame from tracking data
"""

import pandas as pd
import numpy as np
from typing import Optional


class EventFeatureExtractor:
    """Extract frame-level features from player tracking data"""
    
    def __init__(self, fps: float = 30.0):
        """
        Initialize feature extractor
        
        Args:
            fps: Frames per second for velocity/time calculations
        """
        self.fps = fps
    
    def extract_features(self, xy_df: pd.DataFrame) -> pd.DataFrame:
        """
        Extract all features from tracking DataFrame
        
        Args:
            xy_df: Tracking data with columns: frame, object_type, team, x, y, dx, dy, speed
        
        Returns:
            Features DataFrame with columns: frame, feature1, feature2, ...
        """
        # Filter to players only (exclude ball, refs)
        players = xy_df[
            (xy_df['object_type'] == 'player') & 
            (xy_df['team'].isin([1, 2]))
        ].copy()
        
        if players.empty:
            return pd.DataFrame()
        
        # Get all frames
        frames = sorted(players['frame'].unique())
        
        features_list = []
        
        for frame in frames:
            frame_data = players[players['frame'] == frame]
            
            # Extract per-team features
            features = {'frame': frame}
            
            for team in [1, 2]:
                team_data = frame_data[frame_data['team'] == team]
                
                if len(team_data) > 0:
                    # Position stats
                    features[f'team{team}_x_mean'] = team_data['x'].mean()
                    features[f'team{team}_y_mean'] = team_data['y'].mean()
                    features[f'team{team}_x_std'] = team_data['x'].std()
                    features[f'team{team}_y_std'] = team_data['y'].std()
                    features[f'team{team}_x_min'] = team_data['x'].min()
                    features[f'team{team}_x_max'] = team_data['x'].max()
                    features[f'team{team}_y_min'] = team_data['y'].min()
                    features[f'team{team}_y_max'] = team_data['y'].max()
                    
                    # Formation metrics
                    features[f'team{team}_width'] = team_data['x'].max() - team_data['x'].min()
                    features[f'team{team}_depth'] = team_data['y'].max() - team_data['y'].min()
                    features[f'team{team}_compression'] = (
                        features[f'team{team}_width'] / (features[f'team{team}_depth'] + 1.0)
                    )
                    
                    # Velocity stats (if available)
                    if 'speed' in team_data.columns:
                        features[f'team{team}_speed_mean'] = team_data['speed'].mean()
                        features[f'team{team}_speed_std'] = team_data['speed'].std()
                        features[f'team{team}_speed_max'] = team_data['speed'].max()
                        features[f'team{team}_speed_min'] = team_data['speed'].min()
                    
                    if 'dx' in team_data.columns and 'dy' in team_data.columns:
                        features[f'team{team}_dx_mean'] = team_data['dx'].mean()
                        features[f'team{team}_dy_mean'] = team_data['dy'].mean()
                else:
                    # Fill with NaN for missing team
                    for col in ['x_mean', 'y_mean', 'x_std', 'y_std', 
                               'x_min', 'x_max', 'y_min', 'y_max',
                               'width', 'depth', 'compression',
                               'speed_mean', 'speed_std', 'speed_max', 'speed_min',
                               'dx_mean', 'dy_mean']:
                        features[f'team{team}_{col}'] = np.nan
            
            # Cross-team features
            if 'team1_x_mean' in features and 'team2_x_mean' in features:
                if not pd.isna(features['team1_x_mean']) and not pd.isna(features['team2_x_mean']):
                    # Team separation
                    features['team_sep'] = np.sqrt(
                        (features['team1_x_mean'] - features['team2_x_mean'])**2 +
                        (features['team1_y_mean'] - features['team2_y_mean'])**2
                    )
                    
                    # Speed differential
                    if 'team1_speed_mean' in features and 'team2_speed_mean' in features:
                        features['speed_diff'] = abs(
                            features['team1_speed_mean'] - features['team2_speed_mean']
                        )
            
            # Composite scores
            team1_speed = features.get('team1_speed_mean', 0)
            team2_speed = features.get('team2_speed_mean', 0)
            team1_width = features.get('team1_width', 0)
            team_sep = features.get('team_sep', 999)
            
            # Scrum score: low speed + low width + close teams
            features['scrum_score'] = (
                (1.0 / (team1_speed + team2_speed + 1.0)) *
                (1.0 / (team1_width + 1.0)) *
                (1.0 / (team_sep + 1.0))
            )
            
            # Lineout score: low width + high depth
            team1_depth = features.get('team1_depth', 0)
            features['lineout_score'] = (
                (1.0 / (team1_width + 1.0)) *
                (team1_depth + 1.0)
            )
            
            # Try score: in tryzone + low speed
            team1_x = features.get('team1_x_mean', 50)
            in_tryzone = (team1_x < 5) or (team1_x > 95)
            features['try_score'] = (
                (1.0 if in_tryzone else 0.0) *
                (1.0 / (team1_speed + 1.0))
            )
            
            features_list.append(features)
        
        features_df = pd.DataFrame(features_list)
        
        # Fill NaN with 0.0
        features_df = features_df.fillna(0.0)
        
        return features_df


# Standalone test
if __name__ == '__main__':
    import sys
    
    if len(sys.argv) > 1:
        xy_path = sys.argv[1]
    else:
        xy_path = '/home/claude/training_data/All_Blacks_v_Wales_Cardiff_2025_FULL_GAME_chunk_008_9f3ffb_xy.csv'
    
    print(f"Testing feature extraction on: {xy_path}")
    
    xy_df = pd.read_csv(xy_path)
    extractor = EventFeatureExtractor(fps=30.0)
    features_df = extractor.extract_features(xy_df)
    
    print(f"\nExtracted {len(features_df)} frames with {len(features_df.columns)} features")
    print(f"\nFirst 5 rows:")
    print(features_df.head())
    print(f"\nFeature columns:")
    print(list(features_df.columns))
