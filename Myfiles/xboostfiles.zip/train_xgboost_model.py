#!/usr/bin/env python3
"""
XGBoost Event Detection Model Training Pipeline
================================================

This script trains an XGBoost classifier for rugby event detection using
your full-match tracking data and rule-based event labels.

It implements the exact training workflow from EventDetection_Pipeline.ipynb
but adapted for your production pipeline data format.

Usage:
    python train_xgboost_model.py --data-dir /path/to/chunks --output-model models/rugby_xgb.json
"""

import argparse
import pandas as pd
import numpy as np
import xgboost as xgb
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.preprocessing import LabelEncoder
import json
import warnings
warnings.filterwarnings('ignore')

# Assuming your event_features.py is in the correct path
import sys
sys.path.insert(0, '/home/claude')
from worker.rugby_detections.analytics.event_features import EventFeatureExtractor


class RugbyXGBoostTrainer:
    """Train XGBoost model for rugby event detection"""
    
    # Event mapping: your pipeline → notebook format
    EVENT_MAPPING = {
        'Scrum': 'Scrum',
        'Lineout': 'Lineout',
        'Turnover': 'Turnover',
        'KickRestart': 'KickRestart',
        'CollectKick': 'CollectKick',  # Keep as-is or map to KickRestart?
        'Ruck': 'Ruck',
        'Stop': 'OpenPlay',  # Background class
        'Halftime': 'Halftime',
        'Try': 'Try',  # From Phase 3
    }
    
    def __init__(self, fps: float = 30.0, event_duration_s: float = 3.0):
        """
        Initialize trainer
        
        Args:
            fps: Frames per second of video
            event_duration_s: Duration window for each event in seconds
        """
        self.fps = fps
        self.event_duration_frames = int(event_duration_s * fps)
        self.label_encoder = LabelEncoder()
        self.feature_extractor = None
    
    def load_game_data(self, xy_path: str, events_path: str) -> tuple[pd.DataFrame, pd.DataFrame]:
        """
        Load tracking and events data for a single game/chunk
        
        Returns:
            (tracking_df, events_df)
        """
        print(f"📂 Loading: {Path(xy_path).name}")
        
        xy_df = pd.read_csv(xy_path)
        events_df = pd.read_csv(events_path)
        
        print(f"   ✓ {len(xy_df)} tracking rows")
        print(f"   ✓ {len(events_df)} events")
        
        return xy_df, events_df
    
    def prepare_labels(self, xy_df: pd.DataFrame, events_df: pd.DataFrame) -> pd.DataFrame:
        """
        Convert events to per-frame labels
        
        Creates a label for each frame based on event windows.
        Frames without events are labeled 'OpenPlay' (background).
        
        Returns:
            DataFrame with columns: frame, event
        """
        # Get all unique frames
        all_frames = sorted(xy_df['frame'].unique())
        
        # Initialize all frames as OpenPlay
        frame_labels = pd.DataFrame({
            'frame': all_frames,
            'event': 'OpenPlay'
        })
        
        # Assign event labels based on event windows
        for _, event_row in events_df.iterrows():
            event_type = event_row['Event']
            frame_start = int(event_row['frameIdx'])
            frame_end = frame_start + self.event_duration_frames
            
            # Map event type
            mapped_event = self.EVENT_MAPPING.get(event_type, event_type)
            
            # Label all frames in this event window
            mask = (frame_labels['frame'] >= frame_start) & (frame_labels['frame'] <= frame_end)
            frame_labels.loc[mask, 'event'] = mapped_event
        
        print(f"   ✓ Labeled {len(frame_labels)} frames")
        print(f"   Event distribution:")
        for event, count in frame_labels['event'].value_counts().items():
            print(f"      {event}: {count}")
        
        return frame_labels
    
    def extract_features(self, xy_df: pd.DataFrame) -> pd.DataFrame:
        """
        Extract ~200 features per frame using your Phase 2 feature extractor
        
        Returns:
            DataFrame with columns: frame, feature1, feature2, ...
        """
        print(f"   🔄 Extracting features...")
        
        if self.feature_extractor is None:
            self.feature_extractor = EventFeatureExtractor(fps=self.fps)
        
        features_df = self.feature_extractor.extract_features(xy_df)
        
        print(f"   ✓ Extracted {len(features_df.columns)} features for {len(features_df)} frames")
        
        return features_df
    
    def prepare_training_data(self, data_dir: str) -> tuple[pd.DataFrame, pd.Series]:
        """
        Load all game chunks and prepare training data
        
        Args:
            data_dir: Directory containing *_xy.csv and *_events.csv files
        
        Returns:
            (X: features DataFrame, y: labels Series)
        """
        data_path = Path(data_dir)
        
        # Find all xy files
        xy_files = sorted(data_path.glob("*_xy.csv"))
        
        if not xy_files:
            raise ValueError(f"No *_xy.csv files found in {data_dir}")
        
        print(f"\n{'='*60}")
        print(f"📊 Loading training data from {len(xy_files)} chunks")
        print(f"{'='*60}\n")
        
        all_features = []
        all_labels = []
        
        for xy_file in xy_files:
            # Find corresponding events file
            events_file = xy_file.parent / xy_file.name.replace('_xy.csv', '_events.csv')
            
            if not events_file.exists():
                print(f"⚠️  Skipping {xy_file.name} - no events file found")
                continue
            
            # Load data
            xy_df, events_df = self.load_game_data(str(xy_file), str(events_file))
            
            # Extract features
            features_df = self.extract_features(xy_df)
            
            # Prepare labels
            labels_df = self.prepare_labels(xy_df, events_df)
            
            # Merge features and labels on frame
            merged = features_df.merge(labels_df, on='frame', how='inner')
            
            # Separate X and y
            X = merged.drop(columns=['event'])
            y = merged['event']
            
            all_features.append(X)
            all_labels.append(y)
            
            print()
        
        # Concatenate all chunks
        X = pd.concat(all_features, ignore_index=True)
        y = pd.concat(all_labels, ignore_index=True)
        
        print(f"\n{'='*60}")
        print(f"✅ Training data prepared:")
        print(f"   Total samples: {len(X)}")
        print(f"   Features: {len(X.columns)}")
        print(f"   Event distribution:")
        for event, count in y.value_counts().items():
            print(f"      {event}: {count} ({count/len(y)*100:.1f}%)")
        print(f"{'='*60}\n")
        
        return X, y
    
    def train_model(self, X: pd.DataFrame, y: pd.Series, test_size: float = 0.2) -> xgb.XGBClassifier:
        """
        Train XGBoost classifier
        
        Args:
            X: Feature matrix
            y: Labels
            test_size: Fraction for test set
        
        Returns:
            Trained XGBoost model
        """
        print(f"🎯 Training XGBoost model...")
        
        # Encode labels
        y_encoded = self.label_encoder.fit_transform(y)
        
        # Train/test split
        X_train, X_test, y_train, y_test = train_test_split(
            X, y_encoded, test_size=test_size, random_state=42, stratify=y_encoded
        )
        
        print(f"   Train samples: {len(X_train)}")
        print(f"   Test samples: {len(X_test)}")
        
        # Train XGBoost
        model = xgb.XGBClassifier(
            objective='multi:softprob',
            num_class=len(self.label_encoder.classes_),
            max_depth=6,
            learning_rate=0.1,
            n_estimators=100,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=42,
            eval_metric='mlogloss'
        )
        
        print(f"\n   Training...")
        model.fit(
            X_train, y_train,
            eval_set=[(X_test, y_test)],
            verbose=False
        )
        
        # Evaluate
        y_pred = model.predict(X_test)
        
        print(f"\n{'='*60}")
        print("📊 Model Evaluation:")
        print(f"{'='*60}\n")
        
        print("Classification Report:")
        print(classification_report(
            y_test, y_pred,
            target_names=self.label_encoder.classes_,
            zero_division=0
        ))
        
        print("\nConfusion Matrix:")
        cm = confusion_matrix(y_test, y_pred)
        print("Predicted →")
        print("Actual ↓\n")
        
        # Print confusion matrix with labels
        header = "".join([f"{cls:12}" for cls in self.label_encoder.classes_])
        print(f"{'':12}{header}")
        for i, cls in enumerate(self.label_encoder.classes_):
            row = "".join([f"{cm[i, j]:12}" for j in range(len(self.label_encoder.classes_))])
            print(f"{cls:12}{row}")
        
        print(f"\n{'='*60}\n")
        
        return model
    
    def save_model(self, model: xgb.XGBClassifier, output_path: str):
        """
        Save trained model and label encoder
        
        Args:
            model: Trained XGBoost model
            output_path: Path to save model (.json)
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Save model
        model.save_model(str(output_path))
        print(f"✅ Model saved: {output_path}")
        
        # Save label encoder mapping
        label_map_path = output_path.parent / "label_encoder.json"
        label_mapping = {
            int(i): cls for i, cls in enumerate(self.label_encoder.classes_)
        }
        with open(label_map_path, 'w') as f:
            json.dump(label_mapping, f, indent=2)
        print(f"✅ Label mapping saved: {label_map_path}")
        
        print(f"\n📋 Event classes:")
        for i, cls in enumerate(self.label_encoder.classes_):
            print(f"   {i}: {cls}")


def main():
    parser = argparse.ArgumentParser(description='Train XGBoost event detection model')
    
    parser.add_argument(
        '--data-dir',
        required=True,
        help='Directory containing *_xy.csv and *_events.csv files'
    )
    
    parser.add_argument(
        '--output-model',
        default='models/rugby_xgb.json',
        help='Path to save trained model (default: models/rugby_xgb.json)'
    )
    
    parser.add_argument(
        '--fps',
        type=float,
        default=30.0,
        help='Video frames per second (default: 30.0)'
    )
    
    parser.add_argument(
        '--test-size',
        type=float,
        default=0.2,
        help='Fraction for test set (default: 0.2)'
    )
    
    args = parser.parse_args()
    
    # Initialize trainer
    trainer = RugbyXGBoostTrainer(fps=args.fps)
    
    # Prepare training data
    X, y = trainer.prepare_training_data(args.data_dir)
    
    # Train model
    model = trainer.train_model(X, y, test_size=args.test_size)
    
    # Save model
    trainer.save_model(model, args.output_model)
    
    print(f"\n{'='*60}")
    print("🎉 Training complete!")
    print(f"{'='*60}")
    print(f"\nNext steps:")
    print(f"1. Test inference: python worker/rugby_detections/analytics/event_ml.py")
    print(f"2. Integrate into mainAnalytics.py")
    print(f"3. Tune thresholds in config/thresholds_rugby.yaml")
    print(f"{'='*60}\n")


if __name__ == '__main__':
    main()
